package com.example.miniv1;

import android.os.Bundle;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import me.biubiubiu.justifytext.library.JustifyTextView;

public class youtubeVideo extends YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener {

    //    public static final String API_KEY = "AIzaSyD88wIwcsEY61nhShIc1CFKNs9ADlM7S7Q";
//            "AIzaSyBJ65W2I3l8KDB8lBeWSQ9CN3c2a1XM6g8";
    public String VIDEO_ID;
    JustifyTextView jvt;
    private final YouTubePlayer.PlaybackEventListener playbackEventListener = new YouTubePlayer.PlaybackEventListener() {
        @Override
        public void onBuffering(boolean arg0) {
        }

        @Override
        public void onPaused() {
        }

        @Override
        public void onPlaying() {
        }

        @Override
        public void onSeekTo(int arg0) {
        }

        @Override
        public void onStopped() {
        }
    };
    private final YouTubePlayer.PlayerStateChangeListener playerStateChangeListener = new YouTubePlayer.PlayerStateChangeListener() {
        @Override
        public void onAdStarted() {
        }

        @Override
        public void onError(YouTubePlayer.ErrorReason arg0) {
        }

        @Override
        public void onLoaded(String arg0) {
        }

        @Override
        public void onLoading() {
        }

        @Override
        public void onVideoEnded() {
        }

        @Override
        public void onVideoStarted() {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youtube_video);

        VIDEO_ID = getIntent().getStringExtra("url");
        jvt = findViewById(R.id.jtv_videofeed_detail);

        jvt.setText(getIntent().getStringExtra("detail") + "\n");

        /** Initializing YouTube Player View **/
        YouTubePlayerView youTubePlayerView = findViewById(R.id.youtube_player);
        try {
            youTubePlayerView.initialize("AIzaSyCfdkaUtrvS93t5EeHnP_gMPh8oCmfCG3E", this);
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show();
            finish();
        }

    }

    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult result) {
        Toast.makeText(this, "Failed to Initialize!", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer player, boolean wasRestored) {
        /** add listeners to YouTubePlayer instance **/
        player.setPlayerStateChangeListener(playerStateChangeListener);
        player.setPlaybackEventListener(playbackEventListener);

        /** Start buffering **/
        if (!wasRestored) {
            player.cueVideo(VIDEO_ID);
        }
    }
}

