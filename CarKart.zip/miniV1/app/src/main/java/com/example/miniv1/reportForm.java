package com.example.miniv1;

public class reportForm {
    String pName, pAge, pEmail, diseaseResults, date, time;

    public reportForm() {
    }

    public reportForm(String pName, String pAge, String pEmail, String diseaseResults, String date, String time) {
        this.pName = pName;
        this.pAge = pAge;
        this.pEmail = pEmail;
        this.diseaseResults = diseaseResults;
        this.date = date;
        this.time = time;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public String getpAge() {
        return pAge;
    }

    public void setpAge(String pAge) {
        this.pAge = pAge;
    }

    public String getpEmail() {
        return pEmail;
    }

    public void setpEmail(String pEmail) {
        this.pEmail = pEmail;
    }

    public String getDiseaseResults() {
        return diseaseResults;
    }

    public void setDiseaseResults(String diseaseResults) {
        this.diseaseResults = diseaseResults;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
