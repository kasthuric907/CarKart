package com.example.miniv1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import me.biubiubiu.justifytext.library.JustifyTextView;

public class AdapterVideofeed extends RecyclerView.Adapter<AdapterVideofeed.MyHolder> {

    List<videofeed_info_model> VideofeedList;
    private final Context context;

    public AdapterVideofeed(Context context, List<videofeed_info_model> VideofeedList) {
        this.context = context;
        this.VideofeedList = VideofeedList;
    }

    @NonNull
    @Override
    public AdapterVideofeed.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.videofeed_list, parent, false);
        AdapterVideofeed.MyHolder holder = new AdapterVideofeed.MyHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final AdapterVideofeed.MyHolder holder, final int position) {

        final String videofeedUrl = VideofeedList.get(position).getVideourl();
        final String videofeedDesc = VideofeedList.get(position).getVideodesc();
        final String videofeedDetail = VideofeedList.get(position).getVideodetail();

        holder.jtv.setText(" " + videofeedDesc + "\n");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, youtubeVideo.class);
                intent.putExtra("url", videofeedUrl);
                intent.putExtra("detail", videofeedDetail);

                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return VideofeedList.size();
    }

    class MyHolder extends RecyclerView.ViewHolder {

        JustifyTextView jtv;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            jtv = itemView.findViewById(R.id.jtv_videoDesc);
        }
    }

}