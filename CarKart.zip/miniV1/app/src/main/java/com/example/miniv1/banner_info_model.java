package com.example.miniv1;

public class banner_info_model {
    String banimg, banurl;

    public banner_info_model() {
    }

    public banner_info_model(String banimg, String banurl) {
        this.banimg = banimg;
        this.banurl = banurl;
    }

    public String getBanimg() {
        return banimg;
    }

    public String getBanurl() {
        return banurl;
    }
}
