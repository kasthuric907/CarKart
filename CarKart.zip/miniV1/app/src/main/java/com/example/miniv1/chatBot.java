package com.example.miniv1;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class chatBot extends AppCompatActivity {

    ImageView loadingLogo;
    Animation animation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_bot);

        loadingLogo = findViewById(R.id.img_loading);
        animation = AnimationUtils.loadAnimation(this, R.anim.animation);

        loadingLogo.startAnimation(animation);

    }
}
