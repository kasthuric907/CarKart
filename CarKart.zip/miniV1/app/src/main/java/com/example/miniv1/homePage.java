package com.example.miniv1;

import android.Manifest;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.AlarmClock;
import android.provider.Contacts;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.blogspot.atifsoftwares.circularimageview.CircularImageView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

public class homePage extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    public String imageURL = "";
    TextView head_name;
    DatabaseReference DB_profileRef;

    boolean doubleBackToExitPressedOnce = false;

    Dialog profileDialog;
    Dialog addMedReminderDialog;
    Dialog mailDialog;
    Dialog messageDialog;
    CircularImageView civProfile;
    private DrawerLayout navDrawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_drawer_layout);
//
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN);


        profileDialog = new Dialog(homePage.this);
        addMedReminderDialog = new Dialog(homePage.this);
        mailDialog = new Dialog(homePage.this);
        messageDialog = new Dialog(homePage.this);

        Toolbar toolbar = findViewById(R.id.homepage_toolbar);
        setSupportActionBar(toolbar);

        navDrawer = findViewById(R.id.drawer_layout);

        NavigationView navigationView = findViewById(R.id.navigationView);

        //      updating navigation header
        navigationView.setNavigationItemSelectedListener(this);

        View headView = navigationView.getHeaderView(0);

        head_name = headView.findViewById(R.id.header_layout_name);

        civProfile = findViewById(R.id.civ_profile);

        FirebaseDatabase.getInstance().getReference("userInformation").child(FirebaseAuth.getInstance().getUid());


        DB_profileRef = FirebaseDatabase.getInstance().getReference("userInformation").child(FirebaseAuth.getInstance().getUid());

        DB_profileRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String name = dataSnapshot.child("fName").getValue().toString();
                String profile_url = dataSnapshot.child("url").getValue().toString();
                imageURL = profile_url;

                head_name.setText("Hello " + name + "!");
                Picasso.get().load(profile_url).placeholder(R.mipmap.ic_launcher)
                        .error(R.mipmap.ic_launcher)
                        .into(civProfile, new Callback() {

                            @Override
                            public void onSuccess() {

                            }

                            @Override
                            public void onError(Exception e) {

                            }
                        });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(homePage.this, "DB error: " + databaseError.toString(), Toast.LENGTH_SHORT).show();
            }
        });


        civProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navDrawer.closeDrawer((GravityCompat.START));
                finish();
                startActivity(new Intent(homePage.this, profilePage.class));
            }
        });


        civProfile.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                profileDialog.setContentView(R.layout.profile_dialogbox);

                CircularImageView cimv = profileDialog.findViewById(R.id.profile_pic);

                try {
                    Picasso.get().load(imageURL)
                            .placeholder(R.drawable.ic_search_black_24dp)
                            .into(cimv);
                } catch (Exception e) {

                }

                Animation animation = AnimationUtils.loadAnimation(homePage.this, R.anim.animation1);
                cimv.startAnimation(animation);


                profileDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                profileDialog.show();

                return false;
            }
        });


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, navDrawer, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);

        navDrawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new homeFragment())
                    .commit();

            navigationView.setCheckedItem(R.id.nav_home);
        }

    }


    @Override
    public void onBackPressed() {

        if (navDrawer.isDrawerOpen(GravityCompat.START)) {
            navDrawer.closeDrawer(GravityCompat.START);
        }

        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000);
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new homeFragment())
                        .commit();
                break;

            case R.id.nav_checkup:
//                getSupportFragmentManager().beginTransaction()
//                        .replace(R.id.fragment_container, new checkUpFragment())
//                        .commit();
                startActivity(new Intent(homePage.this, myTensorflow.class));
                finish();
                break;

            case R.id.nav_reports:
                Intent i = getPackageManager().getLaunchIntentForPackage("com.VAugment.CarMachineLearning");
                startActivity(i);
                //startActivity(new Intent(homePage.this, reports.class));
                //finish();

//                getSupportFragmentManager().beginTransaction()
//                        .replace(R.id.fragment_container, new reportsFragment())
//                        .commit();
                break;

            case R.id.nav_search:
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new searchFragment())
                        .commit();
                break;

            case R.id.nav_hospitals:
//                getSupportFragmentManager().beginTransaction()
//                        .replace(R.id.fragment_container, new hospitalsFragment())
//                        .commit();

                startActivity(new Intent(homePage.this, nearByHospitals.class));
                finish();
                break;

            case R.id.nav_saveContacts:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_CONTACTS)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.WRITE_CONTACTS}, 3);
                } else {
                    addContact("Car Dealer 1", "111");
                    addContact("Car Dealer 2", "222");
                    addContact("Car Dealer 3", "333");
                }
                break;

            case R.id.nav_medReminder:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.SET_ALARM)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.SET_ALARM}, 4);
                } else {
                    showMedReminderDialog();
                }
                break;

            case R.id.nav_mail:
//                startActivity(new Intent(homePage.this, readTry.class));
                showMailDialog();
                break;

            case R.id.nav_phone:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                        checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 5);
                } else {
                    makeCall();
                }
                break;

            case R.id.nav_message:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 0);
                } else {
                    showMessageDialog();
                }
                break;

            case R.id.nav_chatbot:
                //startActivity(new Intent(homePage.this, chatBot.class));
                Toast.makeText(this, "Chat bot will be aviliable soon", Toast.LENGTH_SHORT).show();
                break;

            case R.id.nav_logout:

                AlertDialog.Builder builder = new AlertDialog.Builder(homePage.this);
                builder.setMessage("Do you want to logout?")
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FirebaseAuth.getInstance().signOut();
                                startActivity(new Intent(homePage.this, MainActivity.class));
                                finish();
                            }
                        })
                        .setNegativeButton("NO", null);
                AlertDialog alert = builder.create();
                alert.show();
                break;

            case R.id.nav_about:
                startActivity(new Intent(homePage.this, aboutPopUp.class));
                break;

            case R.id.nav_download:
                clicked_btn("https://drive.google.com/open?id=1ffg7YX-4u9BSizErWNx-0-TS04bzo1ab");
                //clicked_btn("https://drive.google.com/open?id=1YEksjM93k8bRnz658tFfgxT21ybt_qbl");
                break;
        }

        navDrawer.closeDrawer((GravityCompat.START));

        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void makeCall() {
        String pNumber = "tel:9113659214";
        final Intent intent = new Intent(Intent.ACTION_CALL);

        intent.setData(Uri.parse(pNumber));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(this, "Please grant permissions", Toast.LENGTH_SHORT).show();
            requestPermissions(new String[]{Manifest.permission.SET_ALARM}, 1);

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(homePage.this);
            builder.setMessage("Do you want to make a call to CarKart (" + pNumber + ")?")
                    .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            startActivity(intent);
                        }
                    })
                    .setNegativeButton("NO", null);
            AlertDialog alert = builder.create();
            alert.show();
        }
    }


    public void clicked_btn(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 0:

                if (grantResults.length >= 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    showMessageDialog();
                } else {
                    Toast.makeText(this, "Please grant messaging permissions.", Toast.LENGTH_SHORT).show();
                }

                break;

            case 3:
                try {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        addContact("Car Dealer 1", "111");
                        addContact("Car Dealer 2", "222");
                        addContact("Car Dealer 3", "333");
                    } else {
                        requestPermissions(new String[]{Manifest.permission.WRITE_CONTACTS}, 3);
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "Exception: " + e, Toast.LENGTH_SHORT).show();
                }
                break;
            case 4:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    showMedReminderDialog();
                } else {
                    Toast.makeText(this, "Alarm permissions not given", Toast.LENGTH_SHORT).show();
//                    requestPermissions(new String[]{Manifest.permission.SET_ALARM}, 4);
                }
                break;
            case 5:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    makeCall();
                } else {
                    Toast.makeText(this, "Call permissions not given.", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }


    public void showMedReminderDialog() {
        final EditText message_et, hours_et, min_et;
        Button add_btn;
        TextView close_tv;

        addMedReminderDialog.setContentView(R.layout.add_med_reminder_dialog);

        message_et = addMedReminderDialog.findViewById(R.id.et_text);
        hours_et = addMedReminderDialog.findViewById(R.id.et_hours);
        min_et = addMedReminderDialog.findViewById(R.id.et_min);
        close_tv = addMedReminderDialog.findViewById(R.id.tv_close);
        add_btn = addMedReminderDialog.findViewById(R.id.btn_add);

        close_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addMedReminderDialog.dismiss();
            }
        });

        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = message_et.getText().toString();
                if (hours_et.getText().toString().equals("") || hours_et.getText().toString().equals("")) {
                    Toast.makeText(homePage.this, "Give the time of alarm", Toast.LENGTH_SHORT).show();
                    return;
                }
                int hours = Integer.parseInt(hours_et.getText().toString());
                int min = Integer.parseInt(min_et.getText().toString());

                Intent addAlarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);

                addAlarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, message);
                addAlarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hours);
                addAlarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, min);

                if (hours <= 23 && min <= 59) {
                    startActivity(addAlarmIntent);
                    addMedReminderDialog.dismiss();
                    return;
                } else {
                    Toast.makeText(homePage.this, "Give the correct range", Toast.LENGTH_SHORT).show();
                }
            }
        });

        addMedReminderDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        addMedReminderDialog.show();
    }

    private void showMailDialog() {
        final EditText sub_et, body_et;
        Button send_btn;
        TextView close_tv;

        mailDialog.setContentView(R.layout.mail_dialog);

        sub_et = mailDialog.findViewById(R.id.et_subject);
        body_et = mailDialog.findViewById(R.id.et_body);
        close_tv = mailDialog.findViewById(R.id.tv_close);
        send_btn = mailDialog.findViewById(R.id.btn_sendMail);

        close_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mailDialog.dismiss();
            }
        });

        send_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sub = sub_et.getText().toString();
                String body = body_et.getText().toString();

                String myMailId = "palaceonwheels2020@gmail.com";
                String[] emails = myMailId.split(",");

                Intent sendMail = new Intent(Intent.ACTION_SEND);

                sendMail.putExtra(Intent.EXTRA_EMAIL, emails);
                sendMail.putExtra(Intent.EXTRA_SUBJECT, sub);
                sendMail.putExtra(Intent.EXTRA_TEXT, body);
                sendMail.setType("message/rfc822");
                sendMail.setPackage("com.google.android.gm");

                startActivity(sendMail);
                mailDialog.dismiss();
            }
        });

        mailDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mailDialog.show();
    }

    private void showMessageDialog() {
        final EditText message_et;
        Button send_btn;
        TextView close_tv;

        messageDialog.setContentView(R.layout.message_dialog);

        message_et = messageDialog.findViewById(R.id.et_message);
        close_tv = messageDialog.findViewById(R.id.tv_close);
        send_btn = messageDialog.findViewById(R.id.btn_sendMessage);

        close_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                messageDialog.dismiss();
            }
        });

        send_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String message = message_et.getText().toString();
                final String pNumber = "9113659214";

                if (message.equals("")) {
                    Toast.makeText(homePage.this, "Please enter message", Toast.LENGTH_SHORT).show();
                } else {

                    AlertDialog.Builder builder = new AlertDialog.Builder(homePage.this);
                    builder.setMessage("Send Message to , CarKart (" + pNumber + ") ?")
                            .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    SmsManager smsManager = SmsManager.getDefault();
                                    smsManager.sendTextMessage(pNumber, null, message, null, null);
                                    Toast.makeText(homePage.this, "Message Sent.", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton("NO", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                    messageDialog.dismiss();
                }
            }
        });

        messageDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        messageDialog.show();
    }

    private void addContact(String name, String phone) {
        try {
            ContentValues values = new ContentValues();
            values.put(Contacts.People.NUMBER, phone);
            values.put(Contacts.People.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_CUSTOM);
            values.put(Contacts.People.LABEL, name);
            values.put(Contacts.People.NAME, name);
            Uri dataUri = getContentResolver().insert(Contacts.People.CONTENT_URI, values);
            Uri updateUri = Uri.withAppendedPath(dataUri, Contacts.People.Phones.CONTENT_DIRECTORY);
            values.clear();
            values.put(Contacts.People.Phones.TYPE, Contacts.People.TYPE_MOBILE);
            values.put(Contacts.People.NUMBER, phone);
            updateUri = getContentResolver().insert(updateUri, values);

            Toast.makeText(this, "Contact added", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Exception: " + e, Toast.LENGTH_SHORT).show();
//            TextView tv = new TextView(this);
//            tv.setText(e.toString());
//            setContentView(tv);
        }
    }

}
