package com.example.miniv1;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.github.ybq.android.spinkit.sprite.Sprite;
import com.github.ybq.android.spinkit.style.Wave;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class profilePage extends AppCompatActivity {

    TextView tvSave, tvEmail, tvProfileName;
    ImageView imgBack;
    CircleImageView civProfilePic;
    EditText etFName, etLname, etGender, etAge, etNumber;
    Button btnLogOut;

    TextView tvCountry, tvState, tvDistrict, tvCity, tvFullAddress, tvPinCode;

    DatabaseReference DB_profileRef;

    //Dialog loadingDialog;

    String fname, lname, email, password, profile_url, date, coverUrl, age, gender, phooneNo;

    LinearLayout l1, lp;

    Dialog changePwdDialog;

    //address
    int PERMISSION_ID = 44;
    FusedLocationProviderClient mFusedLocationClient;
    private final LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            Location mLastLocation = locationResult.getLastLocation();
            fillAddress(mLastLocation.getLatitude(), mLastLocation.getLongitude());
        }
    };

    @Override
    public void onBackPressed() {
        finish();
        startActivity(new Intent(profilePage.this, MainActivity.class));
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);

        ProgressBar progressBar = findViewById(R.id.spin_kit);
        Sprite Wave = new Wave();
        progressBar.setIndeterminateDrawable(Wave);

        changePwdDialog = new Dialog(this);

        tvSave = findViewById(R.id.tv_save);
        tvProfileName = findViewById(R.id.tv_profile_name);
        imgBack = findViewById(R.id.img_back);
        civProfilePic = findViewById(R.id.civ_profile_pic);
        etFName = findViewById(R.id.et_first_name);
        etLname = findViewById(R.id.et_last_name);
        etAge = findViewById(R.id.et_age);
        etGender = findViewById(R.id.et_gender);
        etNumber = findViewById(R.id.et_phone_no);
        tvEmail = findViewById(R.id.tv_emaill);

        l1 = findViewById(R.id.linearLayout);
        lp = findViewById(R.id.linearLayout_progressbar);

        tvCountry = findViewById(R.id.tv_country);
        tvState = findViewById(R.id.tv_state);
        tvDistrict = findViewById(R.id.tv_district);
        tvCity = findViewById(R.id.tv_city);
        tvFullAddress = findViewById(R.id.tv_cfull_address);
        tvPinCode = findViewById(R.id.tv_pincode);

        btnLogOut = findViewById(R.id.btn_logout);

        //address
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        getLastLocation();

        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(profilePage.this, MainActivity.class));
            }
        });

        DB_profileRef = FirebaseDatabase.getInstance().getReference("userInformation").child(FirebaseAuth.getInstance().getCurrentUser().getUid());

        DB_profileRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                fname = dataSnapshot.child("fName").getValue().toString();
                lname = dataSnapshot.child("lName").getValue().toString();
                email = dataSnapshot.child("email").getValue().toString();
                password = dataSnapshot.child("psw").getValue().toString();
                profile_url = dataSnapshot.child("url").getValue().toString();
                date = dataSnapshot.child("date").getValue().toString();
                coverUrl = "https://firebasestorage.googleapis.com/v0/b/miniv1.appspot.com/o/apppics%2Fprofilebg.png?alt=media&token=b688c7d9-d9d4-4523-93e2-3dddad0c5d9e";
                gender = dataSnapshot.child("gender").getValue().toString();
                age = dataSnapshot.child("age").getValue().toString();
                phooneNo = dataSnapshot.child("number").getValue().toString();

                tvProfileName.setText(fname + " " + lname);
                etFName.setText(fname);
                etLname.setText(lname);
                etAge.setText(age);
                etGender.setText(gender);
                etNumber.setText(phooneNo);
                tvEmail.setText(email);

                LinearLayout l2 = findViewById(R.id.linearLayout2);
                l2.setVisibility(View.VISIBLE);

                try {
                    Picasso.get().load(profile_url).placeholder(R.mipmap.ic_launcher)
                            .error(R.mipmap.ic_launcher)
                            .into(civProfilePic, new Callback() {

                                @Override
                                public void onSuccess() {

                                }

                                @Override
                                public void onError(Exception e) {

                                }
                            });
                } catch (Exception e) {

                }

                new LoadBackground(coverUrl,
                        "androidfigure").execute();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(profilePage.this, "DB error: " + databaseError.toString(), Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
        });

        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(profilePage.this, homePage.class));
                finish();
                return;
            }
        });

        tvSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lp.setVisibility(View.VISIBLE);
                updateUserInfo();
                lp.setVisibility(View.INVISIBLE);
                return;
            }
        });
    }

    public void updateUserInfo() {
        final String fname = etFName.getText().toString().trim();
        final String lname = etLname.getText().toString().trim();
        final String gender = etGender.getText().toString().trim();
        final String age = etAge.getText().toString().trim();
        final String number = etNumber.getText().toString().trim();

        if (TextUtils.isEmpty(fname) || TextUtils.isEmpty(lname)) {
            Toast.makeText(profilePage.this, "Please enter your name.", Toast.LENGTH_SHORT).show();
            return;
        }

        signUpFormFB userInfo = new signUpFormFB(fname, lname, email, password, profile_url, date, "email", coverUrl, number, age, gender);

        FirebaseDatabase.getInstance().getReference("userInformation").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(userInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                Toast.makeText(profilePage.this, "Successfully Updated", Toast.LENGTH_SHORT).show();
                return;
            }
        });
    }


    //address

    @SuppressLint("MissingPermission")
    private void getLastLocation() {
        if (checkPermissions()) {
            if (isLocationEnabled()) {
                mFusedLocationClient.getLastLocation().addOnCompleteListener(
                        new OnCompleteListener<Location>() {
                            @RequiresApi(api = Build.VERSION_CODES.O)
                            @Override
                            public void onComplete(@NonNull Task<Location> task) {
                                Location location = task.getResult();
                                if (location == null) {
                                    requestNewLocationData();
                                } else {
                                    Date date = Calendar.getInstance().getTime();
                                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                                    String strDate = dateFormat.format(date);
                                    String strTime = strDate.split(" ", 2)[1];
                                    strDate = strDate.split(" ", 2)[0];

                                    locationForm lForm = new locationForm(location.getLatitude(), location.getLongitude(), strTime);


                                    FirebaseDatabase.getInstance().getReference("locations").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(strDate).child(strTime).setValue(lForm).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            return;
                                        }
                                    });

                                    fillAddress(location.getLatitude(), location.getLongitude());
                                }
                            }
                        }
                );
            } else {
                Toast.makeText(this, "Turn on location", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        } else {
            requestPermissions();
        }
    }

    @SuppressLint("MissingPermission")
    private void requestNewLocationData() {

        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(0);
        mLocationRequest.setFastestInterval(0);
        mLocationRequest.setNumUpdates(1);

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mFusedLocationClient.requestLocationUpdates(
                mLocationRequest, mLocationCallback,
                Looper.myLooper()
        );

    }

    private boolean checkPermissions() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION},
                PERMISSION_ID
        );
    }

    private boolean isLocationEnabled() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
                LocationManager.NETWORK_PROVIDER
        );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_ID) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocation();
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (checkPermissions()) {
            getLastLocation();
        }

    }

    private void fillAddress(double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses;

        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1);

            String address = addresses.get(0).getAddressLine(0);
            String postalCode = addresses.get(0).getPostalCode();
            String city = addresses.get(0).getSubLocality();
            String district = addresses.get(0).getSubAdminArea();
            String state = addresses.get(0).getAdminArea();
            String country = addresses.get(0).getCountryName();

            tvCountry.setText(country);
            tvCountry.setGravity(4);
            tvState.setText(state);
            tvDistrict.setText(district);
            tvCity.setText(city);
            tvFullAddress.setText(address);
            tvPinCode.setText(postalCode);

//            Toast.makeText(this,
//                    addresses.get(0).getAddressLine(0) + "\n" +
//                            addresses.get(0).getAddressLine(1) + "\n" +
//                            addresses.get(0).getAddressLine(1) + "\n" +
//                            addresses.get(0).getAdminArea() + "\n"+
//                            addresses.get(0).getCountryCode() + "\n"+
//                            addresses.get(0).getCountryName() + "\n"+
//                            addresses.get(0).getFeatureName() + "\n"+
//                            addresses.get(0).getLocality() + "\n"+
//                            addresses.get(0).getLatitude() + "\n"+
//                            addresses.get(0).getLocale() + "\n"+
//                            addresses.get(0).getLongitude() + "\n"+
//                            addresses.get(0).getMaxAddressLineIndex() + "\n"+
//                            addresses.get(0).getPhone() + "\n"+
//                            addresses.get(0).getPostalCode() + "\n"+
//                            addresses.get(0).getPremises() + "\n"+
//                            addresses.get(0).getSubLocality() + "\n"+
//                            addresses.get(0).getSubThoroughfare() + "\n"+
//                            addresses.get(0).getThoroughfare() + "\n"+
//                            addresses.get(0).getUrl(),
//                    Toast.LENGTH_LONG).show();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void showDialog(View v) {
        final EditText etNewPwd;
        Button cngPwd_btn;
        TextView tvClose;

        changePwdDialog.setContentView(R.layout.cng_pwd_dialog_box);

        cngPwd_btn = changePwdDialog.findViewById(R.id.btn_cng_pwd);
        etNewPwd = changePwdDialog.findViewById(R.id.et_new_pwd);
        tvClose = changePwdDialog.findViewById(R.id.tv_close);

        tvClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changePwdDialog.dismiss();
            }
        });

        cngPwd_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String str_newPwd = etNewPwd.getText().toString();

                if (str_newPwd.length() >= 8) {
                    lp.setVisibility(View.VISIBLE);
                    FirebaseAuth.getInstance().getCurrentUser().updatePassword(str_newPwd).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(profilePage.this, "Password changed successfully.", Toast.LENGTH_SHORT).show();

                            signUpFormFB userInfo = new signUpFormFB(fname, lname, email, str_newPwd, profile_url, date, "email", coverUrl, phooneNo, age, gender);

                            FirebaseDatabase.getInstance().getReference("userInformation").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(userInfo);
                            lp.setVisibility(View.INVISIBLE);
                        }
                    });

                    changePwdDialog.dismiss();
                } else {
                    Toast.makeText(profilePage.this, "Password should be minimum 8 characters.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        changePwdDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        changePwdDialog.show();

    }

    private class LoadBackground extends AsyncTask<String, Void, Drawable> {

        private final String imageUrl;
        private final String imageName;

        public LoadBackground(String url, String file_name) {
            this.imageUrl = url;
            this.imageName = file_name;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Drawable doInBackground(String... urls) {

            try {
                InputStream is = (InputStream) this.fetch(this.imageUrl);
                Drawable d = Drawable.createFromStream(is, this.imageName);
                return d;
            } catch (MalformedURLException e) {
                e.printStackTrace();
                return null;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        private Object fetch(String address) throws IOException {
            URL url = new URL(address);
            Object content = url.getContent();
            return content;
        }

        @Override
        protected void onPostExecute(Drawable result) {
            super.onPostExecute(result);
            l1.setBackgroundDrawable(result);
            l1.setVisibility(View.VISIBLE);
            LinearLayout lProgress = findViewById(R.id.linearLayout_progressbar);
            lProgress.setVisibility(View.INVISIBLE);
        }
    }

}
