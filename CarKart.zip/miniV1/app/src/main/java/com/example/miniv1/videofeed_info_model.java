package com.example.miniv1;

public class videofeed_info_model {
    String videourl, videodesc, videodetail;

    public videofeed_info_model() {
    }

    public videofeed_info_model(String videourl, String videodesc, String videodetail) {
        this.videourl = videourl;
        this.videodesc = videodesc;
        this.videodetail = videodetail;
    }

    public String getVideourl() {
        return videourl;
    }

    public void setVideourl(String videourl) {
        this.videourl = videourl;
    }

    public String getVideodesc() {
        return videodesc;
    }

    public void setVideodesc(String videodesc) {
        this.videodesc = videodesc;
    }

    public String getVideodetail() {
        return videodetail;
    }

    public void setVideodetail(String videodetail) {
        this.videodetail = videodetail;
    }
}

 /*   public videofeed_info_model() {
    }

    public videofeed_info_model(String videourl, String videodesc, String videodetail) {
        this.videourl = videourl;
        this.videodesc = videodesc;
        this.videodetail = videodetail;
    }

    public String getVideoUrl() {
        return videourl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videourl = videourl;
    }

    public String getVideoDesc() {
        return videodesc;
    }

    public void setVideoDesc(String videoDesc) {
        this.videodesc = videodesc;
    }

    public String getVideoDetail() {
        return videodetail;
    }

    public void setVideoDetail(String videoDetail) {
        this.videodetail = videodetail;
    }
}*/
