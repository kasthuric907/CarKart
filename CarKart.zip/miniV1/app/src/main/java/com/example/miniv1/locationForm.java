package com.example.miniv1;

public class locationForm {
    Double lat, lon;
    String date;

    public locationForm() {
    }

    public locationForm(Double lat, Double lon, String date) {
        this.lat = lat;
        this.lon = lon;
        this.date = date;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public String getDate() {
        return date;
    }

    public void setEmail(String email) {
        this.date = date;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        this.lon = lon;
    }
}
