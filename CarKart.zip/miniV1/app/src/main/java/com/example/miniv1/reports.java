package com.example.miniv1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.gigamole.infinitecycleviewpager.HorizontalInfiniteCycleViewPager;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class reports extends AppCompatActivity {

    DatabaseReference db_ref;
    ArrayList<reportForm> reportList;

    HorizontalInfiniteCycleViewPager pager;
    AdapterReport adapterReport;

    TextView name, age, email, disease, symptoms, disease_details;
    public BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Get extra data included in the Intent
            name.setText(intent.getStringExtra("pName"));
            age.setText(intent.getStringExtra("pAge"));
            email.setText(intent.getStringExtra("pEmail"));
            disease.setText(intent.getStringExtra("diseaseResults"));
            if (intent.getStringExtra("diseaseResults").equals("Melanocytic nevi")) {
                symptoms.setText(R.string.nv);
                disease_details.setText(R.string.nv_symptoms);
            } else {
                symptoms.setText(R.string.ls);
                disease_details.setText(R.string.ls_symptoms);
            }
        }
    };

    @Override
    public void onBackPressed() {
        finish();
        startActivity(new Intent(reports.this, homePage.class));
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        name = findViewById(R.id.pName);
        age = findViewById(R.id.pAge);
        email = findViewById(R.id.pEmail);
        disease = findViewById(R.id.pDisease);
        symptoms = findViewById(R.id.tv_disease_symptoms);
        disease_details = findViewById(R.id.tv_diseaseDetails);

        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver,
                new IntentFilter("custom-message"));

        db_ref = FirebaseDatabase.getInstance().getReference("userReports").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        reportList = new ArrayList<reportForm>();

        initData();

    }

    private void initData() {
        db_ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                reportList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    reportForm userInfoModel = ds.getValue(reportForm.class);
                    reportList.add(userInfoModel);
                }
                if (reportList.size() == 0) {
                    Toast.makeText(reports.this, "No reports yet", Toast.LENGTH_SHORT).show();
                    finish();
                    startActivity(new Intent(reports.this, homePage.class));
                }
                pager = findViewById(R.id.hicvp_report);
                adapterReport = new AdapterReport(reportList, getBaseContext());
                pager.setAdapter(adapterReport);

                return;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(reports.this, "Cancelled", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
