package com.example.miniv1;

public class report_info_model {
    String patientName, reportDate;

    public report_info_model() {
    }

    public report_info_model(String patientName, String reportDate) {
        this.patientName = patientName;
        this.reportDate = reportDate;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getReportDate() {
        return reportDate;
    }

    public void setReportDate(String reportDate) {
        this.reportDate = reportDate;
    }
}
