package com.example.miniv1;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blogspot.atifsoftwares.circularimageview.CircularImageView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import java.util.ArrayList;
import java.util.List;

import me.biubiubiu.justifytext.library.JustifyTextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class searchFragment extends Fragment {

    SearchableSpinner searchableSpinner;

    RecyclerView recyclerView;

//    AdapterDiseases adapterDiseases;
//    List<disease_info_model> diseaseList;

    AdapterCars adapterCars;
    List<car_info_model> carList;

//    String selectedDisease;

    String selectedCar;

//    ConstraintLayout cl_diseases;
//    LinearLayout ll_progress;

    ConstraintLayout cl_car;
    LinearLayout ll_progress;

    int i = 0;

    public searchFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_search, container, false);
//////////////////////////////////////////////
        searchableSpinner = v.findViewById(R.id.searchable_spinner_diseases);

        recyclerView = v.findViewById(R.id.disease_recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        carList = new ArrayList<>();

        getAllCar();
//        getAllDisease();
        return v;
    }

    private void getAllCar() {

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Cars");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //diseaseList.clear();
                carList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    //  disease_info_model userInfoModel = ds.getValue(disease_info_model.class);
                    car_info_model userInfoModel = ds.getValue(car_info_model.class);
                    // diseaseList.add(userInfoModel);
                    carList.add(userInfoModel);
                    // adapterDiseases = new AdapterDiseases(getActivity(), diseaseList);
                    adapterCars = new AdapterCars(getActivity(), carList);
                    recyclerView.setAdapter(adapterCars);
                }

                Log.i("jdsbj", "onDataChange: jkbsdkjbs");

                //   List<String> disease_list = new ArrayList<>();

                List<String> car_list = new ArrayList<>();

                for (car_info_model item : carList) {
                    car_list.add(item.getCname());
                }
                //Log.i("kaisar", "onFirebaseLoadSuccess: " + name_list);

                ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, car_list);
                searchableSpinner.setAdapter(adapter);

                selectedCar = searchableSpinner.getSelectedItem().toString();

                searchableSpinner.setTitle("Select Car");


                //searchableSpinner.onSearchableItemClicked(disease_list, searchableSpinner.getSelectedItemPosition());


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        searchableSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (i++ == 0) {
                    return;
                }
                for (car_info_model item : carList) {
                    if (item.getCname().equals(searchableSpinner.getSelectedItem().toString())) {
                        Dialog carDialog;
                        // Dialog diseaseDialog;
                        //  diseaseDialog = new Dialog(getContext());
                        // diseaseDialog.setContentView(R.layout.disease_dialogbox);

                        carDialog = new Dialog(getContext());
                        carDialog.setContentView(R.layout.car_dialogbox);

                        CircularImageView cimv = carDialog.findViewById(R.id.disease_pic);
                        JustifyTextView info = carDialog.findViewById(R.id.tv_disease_info);
                        TextView tv = carDialog.findViewById(R.id.textView3);

                        try {
                            Picasso.get().load(item.getCimage())
                                    .placeholder(R.drawable.ic_search_black_24dp)
                                    .into(cimv);

                        } catch (Exception e) {

                        }
                        try {
                            info.setText(item.getCinfo());
                            tv.setText(item.getCname());
                        } catch (Exception e) {

                        }

                        Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.animation1);
                        cimv.startAnimation(animation);
                        tv.startAnimation(animation);
                        info.startAnimation(animation);

                        carDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        carDialog.show();
                        break;
                    }
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

}
