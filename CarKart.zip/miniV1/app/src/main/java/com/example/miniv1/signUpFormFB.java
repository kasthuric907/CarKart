package com.example.miniv1;

public class signUpFormFB {

    public String fName, lName, email, psw, url, date, type, coverUrl, number, age, gender;


    public signUpFormFB() {

    }

    public signUpFormFB(String fName, String lName, String email, String psw, String url, String date, String type, String coverUrl, String number, String age, String gender) {
        this.fName = fName;
        this.lName = lName;
        this.email = email;
        this.psw = psw;
        this.url = url;
        this.date = date;
        this.type = type;
        this.coverUrl = coverUrl;
        this.number = number;
        this.age = age;
        this.gender = gender;
    }
}
