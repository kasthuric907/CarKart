package com.example.miniv1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class AdapterBanners extends RecyclerView.Adapter<AdapterBanners.MyHolder> {

    List<banner_info_model> bannerList;
    private final Context context;

    public AdapterBanners(Context context, List<banner_info_model> bannerList) {
        this.context = context;
        this.bannerList = bannerList;
    }

    @NonNull
    @Override
    public AdapterBanners.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.banner_cardview, parent, false);
        AdapterBanners.MyHolder holder = new AdapterBanners.MyHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final AdapterBanners.MyHolder holder, final int position) {

        final String bannerImage = bannerList.get(position).getBanimg();
        final String bannerUrl = bannerList.get(position).getBanurl();

        try {
            Picasso.get().load(bannerImage)
                    .into(holder.imageIv);
        } catch (Exception e) {

        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, webView.class);
                intent.putExtra("url", bannerUrl);

                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return bannerList.size();
    }

    class MyHolder extends RecyclerView.ViewHolder {


        ImageView imageIv;


        public MyHolder(@NonNull View itemView) {
            super(itemView);
            imageIv = itemView.findViewById(R.id.imgBanner);
        }
    }

}
