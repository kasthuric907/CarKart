package com.example.miniv1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.viewpager.widget.PagerAdapter;

import java.util.List;

public class AdapterReport extends PagerAdapter {

    List<reportForm> reportList;
    LayoutInflater layoutInflater;
    private final Context context;

    public AdapterReport(List<reportForm> reportList, Context context) {
        this.context = context;
        this.reportList = reportList;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return reportList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view.equals(o);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        View view = layoutInflater.inflate(R.layout.card_item, container, false);
        final TextView tv_patient_name = view.findViewById(R.id.tv_patient_name);
        final TextView tv_report_date = view.findViewById(R.id.tv_report_date);

        tv_patient_name.setText(reportList.get(position).pName);
        tv_report_date.setText(reportList.get(position).date);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "name: " + reportList.get(position).pName + "\ndate:" + reportList.get(position).date, Toast.LENGTH_SHORT).show();
                String pName = reportList.get(position).pName;
                String pAge = reportList.get(position).pAge;
                String pEmail = reportList.get(position).pEmail;
                String diseaseResults = reportList.get(position).diseaseResults;

                Intent intent = new Intent("custom-message");

                intent.putExtra("pName", pName);
                intent.putExtra("pAge", pAge);
                intent.putExtra("pEmail", pEmail);
                intent.putExtra("diseaseResults", diseaseResults);

                LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
            }
        });

        container.addView(view);

        return view;
    }
}
