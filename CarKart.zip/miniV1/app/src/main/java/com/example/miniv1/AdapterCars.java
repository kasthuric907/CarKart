package com.example.miniv1;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.blogspot.atifsoftwares.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

import java.util.List;

import me.biubiubiu.justifytext.library.JustifyTextView;

public class AdapterCars extends RecyclerView.Adapter<AdapterCars.MyHolder> {

    Dialog carDialog;
    List<car_info_model> carList;
    private final Context context;

    public AdapterCars(Context context, List<car_info_model> carList) {
        this.context = context;
        this.carList = carList;
    }

    @NonNull
    @Override

    public AdapterCars.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.car_cardview, parent, false);
        AdapterCars.MyHolder holder = new AdapterCars.MyHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final AdapterCars.MyHolder holder, final int position) {

        final String carImage = carList.get(position).getCimage();
        final String carName = carList.get(position).getCname();
        final String carInfo = carList.get(position).getCinfo();

        holder.carTv.setText(carName);

        try {
            Picasso.get().load(carImage)
                    .placeholder(R.drawable.ic_search_black_24dp)
                    .into(holder.imageIv);
        } catch (Exception e) {

        }

        carDialog = new Dialog(context);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                carDialog.setContentView(R.layout.car_dialogbox);

                CircularImageView cimv = carDialog.findViewById(R.id.disease_pic);
                JustifyTextView info = carDialog.findViewById(R.id.tv_disease_info);
                TextView tv = carDialog.findViewById(R.id.textView3);


                try {
                    Picasso.get().load(carImage)
                            .placeholder(R.drawable.ic_search_black_24dp)
                            .into(cimv);
                } catch (Exception e) {

                }
                try {
                    info.setText(carInfo);
                    tv.setText(carName);
                } catch (Exception e) {

                }

                Animation animation = AnimationUtils.loadAnimation(context, R.anim.animation1);
                cimv.startAnimation(animation);
                tv.startAnimation(animation);
                info.startAnimation(animation);

                carDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                carDialog.show();

            }
        });

    }

    @Override
    public int getItemCount() {
        return carList.size();
    }

    class MyHolder extends RecyclerView.ViewHolder {


        CircularImageView imageIv;
        TextView carTv;
        RelativeLayout parentLayout;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            carTv = itemView.findViewById(R.id.carName);
            imageIv = itemView.findViewById(R.id.car_pic);
            parentLayout = itemView.findViewById(R.id.parent_layout);
        }
    }
}
