package com.example.miniv1;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.example.miniv1.ml.CarModel1;
import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.support.label.Category;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class myTensorflow extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;

    ConstraintLayout cl2, cl3;
    Button btnCapture, btnPredict;
    TextView tv;
    ImageView ivImg;
    EditText et;
    Bitmap bitmap;

    @Override
    public void onBackPressed() {
        startActivity(new Intent(myTensorflow.this, homePage.class));
        finish();
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_tensorflow);

        cl2 = findViewById(R.id.constraint_layout_2);
        cl3 = findViewById(R.id.constraint_layout_3);

        btnCapture = findViewById(R.id.button_capture);
        btnPredict = findViewById(R.id.button_predict);

        et = findViewById(R.id.et);

        tv = findViewById(R.id.textview);

        ivImg = findViewById(R.id.image_view);

        btnCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cl2.setVisibility(View.GONE);
                dispatchTakePictureIntent();
            }
        });

        btnPredict.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {

                cl2.setVisibility(View.VISIBLE);
                try {

                     CarModel1 model = CarModel1.newInstance(getApplicationContext());

                    // Creates inputs for reference.
                    TensorImage image = TensorImage.fromBitmap(bitmap);

                    // Runs model inference and gets result.
                    CarModel1.Outputs outputs = model.process(image);
                    List<Category> probability = outputs.getScoresAsCategoryList();

                    Collections.sort(probability, (o1, o2) -> Float.compare(o1.getScore(), o2.getScore()));

                    for (Category i : probability) {
                        Log.d(i.getLabel(), String.valueOf(i.getScore()));
                    }

                    tv.setText("MODEL: " + probability.get(probability.size()-1).getLabel());
                    // Releases model resources if no longer used.
                    model.close();

                } catch (IOException e) {
                    // TODO Handle the exception
                }

            }
        });

    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            bitmap = (Bitmap) extras.get("data");
            ivImg.setImageBitmap(bitmap);
            cl3.setVisibility(View.VISIBLE);
        }
    }
}