package com.example.miniv1;

public class car_info_model {
    String cname, cimage, cinfo;

    public car_info_model() {
    }

    public car_info_model(String cname, String cimage, String cinfo) {
        this.cname = cname;
        this.cimage = cimage;
        this.cinfo = cinfo;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getCimage() {
        return cimage;
    }

    public void setCimage(String cimage) {
        this.cimage = cimage;
    }

    public String getCinfo() {
        return cinfo;
    }

    public void setCinfo(String cinfo) {
        this.cinfo = cinfo;
    }
}
