package com.example.miniv1;

public class youtubeConfig {
    final static String YT_API_KEY = "AIzaSyCfdkaUtrvS93t5EeHnP_gMPh8oCmfCG3E";

    public youtubeConfig() {
    }

    public static String getYtApiKey() {
        return YT_API_KEY;
    }
}
