package com.example.miniv1;

public class getDate {

    public String date;


    public getDate() {

    }

    public getDate(String date) {
        this.date = date;
    }
}
