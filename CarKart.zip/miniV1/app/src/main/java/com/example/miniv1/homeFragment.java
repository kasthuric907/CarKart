package com.example.miniv1;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class homeFragment extends Fragment {
    RecyclerView recyclerView;
    AdapterBanners adapterBanners;
    List<banner_info_model> bannerList;
    RecyclerView videofeed_recyclerView;
    AdapterVideofeed adapterVideofeed;
    List<videofeed_info_model> videofeedList;
    public homeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_home, container, false);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView = v.findViewById(R.id.banner_recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);

        bannerList = new ArrayList<>();

        getAllBanners();

        videofeed_recyclerView = v.findViewById(R.id.videofeed_recycler_view);
        videofeed_recyclerView.setHasFixedSize(true);
        videofeed_recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        videofeedList = new ArrayList<>();

        getAllVideofeed();

        return v;
    }

    private void getAllVideofeed() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Videofeed");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                videofeedList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    videofeed_info_model videofeedInfoModel = ds.getValue(videofeed_info_model.class);

                    videofeedList.add(videofeedInfoModel);

                    adapterVideofeed = new AdapterVideofeed(getActivity(), videofeedList);

                    videofeed_recyclerView.setAdapter(adapterVideofeed);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void getAllBanners() {

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Banner");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                bannerList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    banner_info_model userInfoModel = ds.getValue(banner_info_model.class);

                    bannerList.add(userInfoModel);

                    adapterBanners = new AdapterBanners(getActivity(), bannerList);

                    recyclerView.setAdapter(adapterBanners);
                }


                List<String> banner_list = new ArrayList<>();

                for (banner_info_model item : bannerList) {
                    banner_list.add(item.getBanimg());
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
