package com.example.miniv1;

import android.app.Dialog;
import android.content.Context;

import java.util.List;

public class carAdapter {
    Dialog diseaseDialog;
    List<car_info_model> carList;
    private Context context;

}
